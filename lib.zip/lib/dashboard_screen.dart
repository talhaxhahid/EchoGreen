import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'background_service.dart';
import 'location_service.dart';
import 'dart:async';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:shared_preferences/shared_preferences.dart';


class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  bool isRunning=false;
  bool uploading=false;
  @override
  void initState() {
    checkBackground();
    super.initState();
    _requestLocation();
  }
  Future<void> checkBackground() async {
    final service = FlutterBackgroundService();
    isRunning=  await  service.isRunning();

    print("Get is Running :" +isRunning.toString());
    final prefs = await SharedPreferences.getInstance();
    final result=await prefs.getString('uploading');
    if(result=='true' && isRunning)
      {
        print("Get is Uploading: true");
        uploading=true;
      }
    else{
      print("Get is Uploading: false");
      await prefs.setString('uploading', 'false');
    }
    FlutterBackgroundService().invoke('checkupload');
    FlutterBackgroundService().on("update").listen((event) {
      if (event != null) {
        print("Message from BG for Upload: "+event["message"].toString());
        setState(() {
          uploading = event["message"] ;
        });
      }
    });
    FlutterBackgroundService().on("stop").listen((event) {
      if (event != null) {
        print("Message from BG for Running : "+event["message"].toString());
        setState(() {
          isRunning = event["message"] ;
        });
      }
    });
    setState(() {
    });
    bool stopped = await waitForServiceToStop(service);
    if (stopped)  {
      await prefs.setString('uploading', 'false');
      setState(() {
        isRunning=false;
        uploading=false;

      });
    };
  }

  Future<void> _requestLocation() async {
    await LocationService.requestLocationPermission();

  }

  final _formKey = GlobalKey<FormState>();
  String tripPurpose='';
  String travelMode='';

  List<String> tripPurposes = [
    'Work', 'Leisure', 'Errand', 'Exercise', 'Shopping', 'School', 'Medical', 'Visiting', 'Tourism'
  ];
  List<String> travelModes = [
    'Car', 'Bike', 'Bus', 'Walk', 'Train', 'Scooter', 'Taxi', 'Subway', 'Plane'
  ];

  void startDataCollection() async {
    final tpurpose = await SharedPreferences.getInstance();
    await tpurpose.setString('purpose', tripPurpose);
    final tmode = await SharedPreferences.getInstance();
    await tmode.setString('mode', travelMode);
    if (tripPurpose != '' && travelMode != '') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Data collection started')),

      );
      initializeService();

      setState(() {
        isRunning=true;
      });
      // Navigate or start data collection process
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please select trip purpose and travel mode')),
      );
    }
  }
  void stopDataCollection() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('uploading', 'true');
    FlutterBackgroundService().invoke('checkupload');
    FlutterBackgroundService().invoke('stopService');
    setState(() {
      uploading=true;
    });
    final service = FlutterBackgroundService();
    bool stopped = await waitForServiceToStop(service);
    if (stopped)  {
      await prefs.setString('uploading', 'false');
      setState(() {
        isRunning=false;
        uploading=false;

      });
    };


  }
  Future<bool> waitForServiceToStop(FlutterBackgroundService service, {Duration checkInterval = const Duration(seconds: 1)}) async {
    Completer<bool> completer = Completer<bool>();

    Timer.periodic(checkInterval, (timer) async {
      print("In UI Timer is Checking to stop it");
      bool isRunning = await service.isRunning();
      if (!isRunning) {
        timer.cancel();
        completer.complete(true);
      }
    });

    return completer.future;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.blueGrey,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Echo Green', style: TextStyle(color: Colors.white)),
            InkWell( onTap: (){
              Navigator.pushNamed(context, '/settings');
            }, child: Icon(Icons.settings_rounded, color: Colors.white)),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Lottie.asset(
                'Assets/register.json',
                width: 300,
                height: 300,
                fit: BoxFit.contain,
              ),
            ),
            SizedBox(height: 20),
            Center(
              child: Text(
                'Start Your Trip',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 30),
            Container(
              decoration: BoxDecoration(
                color: Colors.blueGrey.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blueGrey.shade200),
              ),
              padding: EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        'Trip Purpose',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                      ),
                      Icon(Icons.arrow_drop_down, color: Colors.blueGrey)
                    ],
                  ),
                  SizedBox(
                    height: 50,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: tripPurposes.map((purpose) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 5),
                          child: ChoiceChip(
                            label: Text(purpose),
                            selected: tripPurpose == purpose,
                            onSelected: (selected) {
                              setState(() {
                                tripPurpose = purpose;
                              });
                            },
                            selectedColor: Colors.blueGrey,
                            backgroundColor: Colors.grey[200],
                            labelStyle: TextStyle(
                              color: tripPurpose == purpose ? Colors.white : Colors.black,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Text(
                        'Mode of Travel',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                      ),
                      Icon(Icons.arrow_drop_down, color: Colors.blueGrey)
                    ],
                  ),
                  SizedBox(
                    height: 50,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: travelModes.map((mode) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 5),
                          child: ChoiceChip(
                            label: Text(mode),
                            selected: travelMode == mode,
                            onSelected: (selected) {
                              setState(() {
                                travelMode = mode;
                              });
                            },
                            selectedColor: Colors.blueGrey,
                            backgroundColor: Colors.grey[200],
                            labelStyle: TextStyle(
                              color: travelMode == mode ? Colors.white : Colors.black,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 40),
            Center(
              child: isRunning
                  ? ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor:uploading?Colors.blue: Colors.redAccent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                ),
                    onPressed: uploading?()=>{}:stopDataCollection,
                    child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                    SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2,
                      ),
                    ),
                    SizedBox(width: 10),
                    Text(
                      uploading?'Uploading':'Stop',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                                    ],
                                  ),
                  )
                  :ElevatedButton(
                onPressed: startDataCollection,
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  backgroundColor: Colors.blueGrey,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: Text('Start',style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
