import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:geolocator/geolocator.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:http/http.dart' as http;


Future<void> initializeService() async {

  final service = FlutterBackgroundService();

  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onStart,
      isForegroundMode: true,
      autoStart: false,
    ),
    iosConfiguration: IosConfiguration(

    ),
  );

  service.startService();
}

@pragma('vm:entry-point')
void onStart(ServiceInstance service) async {
  var isUploading = false;
  if (service is AndroidServiceInstance) {
    service.setAsForegroundService();
  }
  int sec = 1;

  final _streamSubscriptions = <StreamSubscription<dynamic>>[];
  await Firebase.initializeApp();
  final dir = await getApplicationDocumentsDirectory();
  final file = File('${dir.path}/sensor_data.json');

  Future<void> appendDataToFile(Map<String, dynamic> newData) async {
    try {
      // Read existing data if available
      List<Map<String, dynamic>> existingData = [];
      if (await file.exists()) {
        String content = await file.readAsString();
        if (content.isNotEmpty) {
          existingData = List<Map<String, dynamic>>.from(jsonDecode(content));
        }
      }

      // Append new data
      existingData.add(newData);

      // Write updated data back to file
      await file.writeAsString(jsonEncode(existingData));
    } catch (e) {
      print("Error writing to JSON file: $e");
    }
  }

  Future<String?> uploadFileToGoFile(File file) async {
    while (true) {
      try {
        var request = http.MultipartRequest(
          'POST',
          Uri.parse('https://store1.gofile.io/uploadFile'),
        );
        request.files.add(await http.MultipartFile.fromPath('file', file.path));

        var response = await request.send();
        var responseData = await response.stream.bytesToString();
        var jsonResponse = jsonDecode(responseData);

        if (jsonResponse['status'] == 'ok') {
          print("File uploaded successfully: ${jsonResponse['data']['downloadPage']}");
          return jsonResponse['data']['downloadPage'];
        } else {
          print("GoFile Upload Error: ${jsonResponse['status']}");
        }
      } catch (e) {
        print("Error uploading file, retrying in 5 seconds: $e");
      }

      // Wait for 5 seconds before retrying
      await Future.delayed(Duration(seconds: 5));
    }
  }


  service.on('checkupload').listen((event) async {
    service.invoke("update", {"message": isUploading});
  });

  service.on('stopService').listen((event) async {
    isUploading = true;
    service.invoke("update", {"message": true});

    await Future.delayed(const Duration(seconds: 2));
    _streamSubscriptions.clear();

    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString('user');
    String? purpose = prefs.getString('purpose');
    String? mode = prefs.getString('mode');

    if (userId == null) {
      print("User ID not found. Cannot generate JSON file.");
      service.stopSelf();
      return;
    }

    try {
      if (await file.exists()) {
        // Read stored data
        String jsonString = await file.readAsString();
        if (jsonString.isEmpty) {
          print("No data found to upload.");
          service.invoke("stop", {"message": false});
          service.stopSelf();
          return;
        }

        // Wrap data with metadata
        Map<String, dynamic> wrappedData = {
          'userId': userId,
          'Purpose': purpose,
          'Mode': mode,
          'data': jsonDecode(jsonString),
        };

        // Write wrapped data to file
        await file.writeAsString(jsonEncode(wrappedData));

        print("Data successfully written to JSON file: ${file.path}");

        // Upload to GoFile.io
        String? uploadedUrl = await uploadFileToGoFile(file);

        if (uploadedUrl != null) {
          file.delete();
          print("Uploaded file URL: $uploadedUrl");

          try {
            DocumentReference userDoc = FirebaseFirestore.instance.collection('users').doc(userId);
            await userDoc.update({'trips': FieldValue.arrayUnion([uploadedUrl])});
            print("Trip URL added successfully!");
          } catch (e) {
            print("Error adding trip URL: $e");
          }
        } else {
          print("File upload failed.");
        }
      } else {
        print("JSON file not found.");
      }
    } catch (e) {
      print("Error processing JSON file: $e");
    }

    isUploading = false;
    service.invoke("stop", {"message": false});
    service.stopSelf();

  });

  Duration sensorInterval = SensorInterval.normalInterval;

  List<GyroscopeEvent> gyroscopeData = [];
  List<UserAccelerometerEvent> accelerometerData = [];
  Position positionData = Position(
    latitude: 0.0,
    longitude: 0.0,
    timestamp: DateTime.now(),
    altitudeAccuracy: 0.0,
    headingAccuracy: 0.0,
    accuracy: 0.0,
    altitude: 0.0,
    heading: 0.0,
    speed: 0.0,
    speedAccuracy: 0.0,
  );

  // Listen to Accelerometer Data
  _streamSubscriptions.add(
    userAccelerometerEventStream(samplingPeriod: sensorInterval).listen(
          (UserAccelerometerEvent event) {
        accelerometerData.add(event);
      },
      onError: (e) {},
      cancelOnError: true,
    ),
  );

  // Listen to Gyroscope Data
  _streamSubscriptions.add(
    gyroscopeEventStream(samplingPeriod: sensorInterval).listen(
          (GyroscopeEvent event) {
        gyroscopeData.add(event);
      },
      onError: (e) {},
      cancelOnError: true,
    ),
  );

  // Listen to GPS Location Data
  Stream<Position>? _positionStream = Geolocator.getPositionStream(
    locationSettings: const LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 0,
    ),
  );

  _positionStream.listen((Position position) {
    positionData = position;
  });

  // Periodically Save Data Every Second
  Timer.periodic(Duration(seconds: 1), (timer) async {
    if (isUploading) {
      timer.cancel();
    }

    print('Storing Locally -> Sec : '+ sec.toString());

    // Save the data directly to JSON file
    await appendDataToFile({
      'time': sec.toString(),
      'accelerometer': accelerometerData.map((e) => {
        'x': double.parse(e.x.toStringAsFixed(6)),
        'y': double.parse(e.y.toStringAsFixed(6)),
        'z': double.parse(e.z.toStringAsFixed(6)),
      }).toList(),
      'gyroscope': gyroscopeData.map((e) => {
        'x': double.parse(e.x.toStringAsFixed(6)),
        'y': double.parse(e.y.toStringAsFixed(6)),
        'z': double.parse(e.z.toStringAsFixed(6)),
      }).toList(),
      'position': {
        'latitude': positionData.latitude,
        'longitude': positionData.longitude,
        'altitude': positionData.altitude,
      },
    });

    // Clear old data after saving
    accelerometerData.clear();
    gyroscopeData.clear();

    sec++;
  });
}


// Get GPS Location
Future<Position?> _getCurrentLocation() async {
  bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    return null;
  }

  LocationPermission permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) return null;
  }

  if (permission == LocationPermission.deniedForever) {
    return null;
  }

  return await Geolocator.getCurrentPosition();
}

// Get Accelerometer Data
Future<AccelerometerEvent?> _getAccelerometerData() async {
  var myevent;
  accelerometerEvents.listen(
        (AccelerometerEvent event) {

      myevent= event;
    },
    onError: (error) {
      // Logic to handle error
      // Needed for Android in case sensor is not available
    },
    cancelOnError: true,
  );
  return myevent;
}

// Get Gyroscope Data
Future<GyroscopeEvent?> _getGyroscopeData() async {
  var myevent;
  gyroscopeEvents.listen(
        (GyroscopeEvent event) {

      myevent= event;
    },
    onError: (error) {
      // Logic to handle error
      // Needed for Android in case sensor is not available
    },
    cancelOnError: true,
  );
  return myevent;
}
